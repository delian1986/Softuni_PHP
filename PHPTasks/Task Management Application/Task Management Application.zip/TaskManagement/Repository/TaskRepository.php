<?php


namespace TaskManagement\Repository;


use Database\DatabaseInterface;
use TaskManagement\DTO\TaskDTO;

class TaskRepository implements TaskRepositoryInterface
{
    /**
     * @var DatabaseInterface
     */
    private $db;

    /**
     * TaskRepository constructor.
     * @param DatabaseInterface $db
     */
    public function __construct(DatabaseInterface $db)
    {
        $this->db = $db;
    }

    public function count():int{
        $qry="SELECT COUNT(id) as TaskCount 
              FROM tasks";

        return intval($this->db->query($qry)
            ->execute()
            ->fetchColumn());
    }

    public function findAll(int $limit =0,int $offset=0): \Generator
    {
        $limitClause="";
        if ($limit>0){
            $limitClause='LIMIT '.$limit." OFFSET $offset";
        }

        $qry="SELECT 
                  id,
                  title,
                  description,
                  location,
                  author_id as firstName,
                  category_id as categoryId,
                  started_on as startedOn,
                  due_date as dueDate
              FROM tasks
              ORDER BY 
                  due_date DESC ,
                  id ASC 
              $limitClause";

        return $this->db->query($qry)
            ->execute()
            ->fetch(TaskDTO::class);
    }

    public function findOne(int $id): TaskDTO
    {
        $qry="SELECT 
                  id,
                  title,
                  description,
                  location,
                  author_id,
                  category_id,
                  started_on,
                  due_date 
              FROM tasks
              WHERE
                  id=?
              ORDER BY 
                  due_date DESC ,
                  id ASC 
              ";

        return $this->db->query($qry)
            ->execute($id)
            ->fetch(TaskDTO::class)
            ->current();
    }

    public function insert(TaskDTO $task): bool
    {
        $qry="INSERT INTO tasks(
                title, 
                description, 
                location, 
                author_id, 
                category_id, 
                started_on, 
                due_date
          )
          VALUES (?,?,?,?,?,?,?)";
        $this->db->query($qry)
            ->execute(
                $task->getTitle(),
                $task->getDescription(),
                $task->getLocation(),
                $task->getAuthor()->getId(),
                $task->getCategory()->getId(),
                $task->getStartedOn(),
                $task->getDueDate()
            );
        return true;
    }

    public function update(TaskDTO $task, int $id): bool
    {
        $qry="UPDATE tasks
               SET
               title=?,
               description=?,
               location=?,
               author_id=?,
               category_id=?,
               started_on=?,
               due_date=?,
               id=?
            WHERE
                id=?
            ";
        $this->db->query($qry)->execute(
            $task->getTitle(),
            $task->getDescription(),
            $task->getLocation(),
            $task->getAuthor()->getId(),
            $task->getCategory()->getId(),
            $task->getStartedOn(),
            $task->getDueDate(),
            $task->getId()
        );

        return true;

    }

    public function delete(int $id): bool
    {
        $qry="DELETE FROM tasks WHERE id=?";
        $this->db->query($qry)->execute($id);

        return true;
    }
}